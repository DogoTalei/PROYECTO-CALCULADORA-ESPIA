# 📲Calculator

Light Mode
![1655729735477](https://user-images.githubusercontent.com/76106639/174606737-ba022578-2c88-4768-a5f9-e483775b922c.jpg)
![1655729735481](https://user-images.githubusercontent.com/76106639/174606826-745dda9b-ca3e-4e56-9b7a-a78329a6fa58.jpg)

Dark Mode
![1655729735483](https://user-images.githubusercontent.com/76106639/174606890-90803ffb-dac8-4049-b196-e6f457b25df0.jpg)
![1655729735486](https://user-images.githubusercontent.com/76106639/174606949-9b7fd765-b9b6-4e60-b48f-8ba394586120.jpg)


• Calculator with Beautiful UI and can do simple and complex calculations and also supports android installations.

# 💻Currently Available For:

• Android 

• IOS (May Be In Future)

• GitHub stars GitHub forks GitHub watchers


Encourage this repo by giving it a Star⭐ .

# 🎁Features:

Calculator is an App(Written in Java), which aims to work as:

– Calculate Simple Calculations 

– Scientific Calculations

– Beautiful UI

– No ADS!

– Free to use

– Small Size app

(more coming soon)

# 💬Want to discuss?
Have any questions, doubts or want to present your opinions, views? You're always welcome. You can start discussions.
